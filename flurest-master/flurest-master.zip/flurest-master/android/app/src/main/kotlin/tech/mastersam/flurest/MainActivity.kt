package tech.mastersam.flurest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
