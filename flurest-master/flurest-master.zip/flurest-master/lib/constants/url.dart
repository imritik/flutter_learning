const String BASE_URL =
    "https://jsonblob.com/api/jsonBlob/dea335b4-caa3-11eb-a730-6fb9a48111eb";

const String ADD_MOVIE_URL = "https://jsonplaceholder.typicode.com/posts";
const String DELETE_MOVIE_URL = "https://jsonplaceholder.typicode.com/posts/";

final String MOVIE_DETAIL_BASEURL =
    "https://jsonblob.com/api/jsonBlob/81205065-cdc2-11eb-9b72-cf97a03f078e/";
